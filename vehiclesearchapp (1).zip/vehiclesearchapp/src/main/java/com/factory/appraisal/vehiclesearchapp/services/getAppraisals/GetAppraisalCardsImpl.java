package com.factory.appraisal.vehiclesearchapp.services.getAppraisals;

import com.factory.appraisal.vehiclesearchapp.Constants;
import com.factory.appraisal.vehiclesearchapp.persistence.dto.AppraiseVehicle;
import com.factory.appraisal.vehiclesearchapp.persistence.dto.PageInfo;
import com.factory.appraisal.vehiclesearchapp.persistence.mapper.AppraisalVehicleMapper;
import com.factory.appraisal.vehiclesearchapp.persistence.model.EAppraiseVehicle;
import com.factory.appraisal.vehiclesearchapp.repository.EAppraiseVehicleRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class GetAppraisalCardsImpl implements GetAppraisalsCard {
    @Autowired
    private EAppraiseVehicleRepo appraiseVehicleRepo;
    @Autowired
    private AppraisalVehicleMapper appraisalVehicleMapper;


    @Override
    public AppraiseVehicle findByVinNumber(String vinNo) {

        EAppraiseVehicle vehicle = appraiseVehicleRepo.findByVinNumberAndValidIsTrue(vinNo.toUpperCase());

        if(vehicle!=null){

        AppraiseVehicle vehicle1=new AppraiseVehicle();

        vehicle1.setAppraisalReferenceId(vehicle.getAppraisalReferenceId());
        vehicle1.setMake(vehicle.getMake());
        vehicle1.setModel(vehicle.getModel());
        vehicle1.setMiles(vehicle.getMiles());
        vehicle1.setAppraisalValue(vehicle.getAppraisalValue());
        vehicle1.setCreatedBy(vehicle.getCreatedBy());
        vehicle1.setImage(Constants.ImagesToUI_PATH +vehicle.getAppraisalReferenceId());

        return vehicle1;
        }

        else throw new RuntimeException("Did not find AppraisalVehicle of  -" + vinNo);

    }

    @Override
    public List<AppraiseVehicle> findAllCards(Integer pageNumber) {

        Pageable pageable = PageRequest.of(pageNumber, 10, Sort.by("createdOn").descending());
        Page<EAppraiseVehicle> pageResult = appraiseVehicleRepo.findAllByValidIsTrueOrderByCreatedOnDesc(pageable);

        List<EAppraiseVehicle>apv = pageResult.toList();

        List<AppraiseVehicle> appraiseVehicleDtos= appraisalVehicleMapper.modelsToDtos(apv);

        ArrayList<EAppraiseVehicle> al1= new ArrayList<>(apv);

        ArrayList<AppraiseVehicle>al2= new ArrayList<>(appraiseVehicleDtos);
        for(int i=0;i<al1.size();i++) {
            al2.get(i).setImage(Constants.ImagesToUI_PATH + al1.get(i).getAppraisalReferenceId());
        }
        PageInfo pageInfo=new PageInfo();
        pageInfo.setTotalPages(al1.size()/10);

      //  Object []ob =new Object[]{pageInfo,al2};


        return al2;
    }
}
