package com.factory.appraisal.vehiclesearchapp.persistence.mapper;

import com.factory.appraisal.vehiclesearchapp.persistence.dto.TransactionEntity;
import com.factory.appraisal.vehiclesearchapp.persistence.model.ETransactionEntity;
import org.mapstruct.*;


@Mapper(componentModel = "spring")
public interface TransactionEntityMapper {


    ETransactionEntity dtoToModel(TransactionEntity transaction);


    TransactionEntity modelToDto(ETransactionEntity eTransactionEntity);


}
