package com.factory.appraisal.vehiclesearchapp.persistence.mapper;

import com.factory.appraisal.vehiclesearchapp.persistence.dto.IdEntity;
import com.factory.appraisal.vehiclesearchapp.persistence.model.EIdEntity;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface IdEntityMapper {
    IdEntity modelToDto(EIdEntity eIdEntity);

    EIdEntity dtoToModel(IdEntity idEntity);

}
