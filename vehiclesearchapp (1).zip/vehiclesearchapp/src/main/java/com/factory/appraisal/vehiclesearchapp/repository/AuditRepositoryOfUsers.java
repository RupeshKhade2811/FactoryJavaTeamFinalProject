package com.factory.appraisal.vehiclesearchapp.repository;

import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

public class AuditRepositoryOfUsers {
    @PersistenceContext
    private EntityManager entityManager;

    @Transactional(readOnly = true)
    public List<Object[]> executeSqlQuery(String field, Long id, Integer offset) {
        String sql = "SELECT b.USER_ID,b.rev,b.revtype,Lag(b."+field+", 1) " +
                "OVER (PARTITION BY b.USER_ID ORDER BY rev.modified_on) " +
                "AS old_value_of_"+field+",b."+field+" AS new_value_of_"+field+",rev.modified_by,rev.modified_on " +
                "FROM factory_aud.USER_REG_AUD AS b,factory_db.USER_REG as rev where b.user_id= "+id+" LIMIT 10 OFFSET "+offset+"";

        List<Object[]> resultList = entityManager.createNativeQuery(sql).getResultList();
        return resultList;
    }
}
