package com.factory.appraisal.vehiclesearchapp.controller.auditController;

import com.factory.appraisal.vehiclesearchapp.services.auditService.AuditUserRegistrationServiceImpl;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/UserAudit")
public class AuditControllerForUser {

    @Autowired
    private AuditUserRegistrationServiceImpl auditUserRegistrationService;

    @ApiOperation(value = "Give Offset with increment of +10",nickname = "Give Audit record of given field")
    @GetMapping("/getAuditOfUserRegistration/{field}/{id}/{offset}")
    public ResponseEntity<List<Map<String,Object>>> getAudit(@PathVariable String field , @PathVariable Long id, @PathVariable Integer offset){
        ArrayList<Map<String,Object>> auditRecords = auditUserRegistrationService.getAuditedData(field,id,offset);
        return new ResponseEntity<>((List<Map<String, Object>>) auditRecords, HttpStatus.ACCEPTED);
    }

}
