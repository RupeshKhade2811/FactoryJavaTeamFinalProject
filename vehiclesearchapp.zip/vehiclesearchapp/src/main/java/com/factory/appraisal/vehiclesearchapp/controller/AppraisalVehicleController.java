package com.factory.appraisal.vehiclesearchapp.controller;
//@author:Rupesh Khade

import com.factory.appraisal.vehiclesearchapp.ExceptionHandle.ErrorResponse;
import com.factory.appraisal.vehiclesearchapp.dto.AppraisalVehicleCard;

import com.factory.appraisal.vehiclesearchapp.dto.AppraiseVehicle;
import com.factory.appraisal.vehiclesearchapp.responseHandler.ApiResponseHandler;
import com.factory.appraisal.vehiclesearchapp.services.AppraiseVehicleServiceImpl;

import io.swagger.annotations.ApiOperation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import springfox.documentation.annotations.ApiIgnore;

import javax.validation.Valid;

import javax.validation.constraints.Min;
import javax.validation.constraints.Size;
import java.io.IOException;


import java.util.List;
import java.util.Map;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/api/appraisal")
public class AppraisalVehicleController {

    @Autowired
    private AppraiseVehicleServiceImpl service;




    @ApiOperation(value = "get Appraisals cards by user id ", response = AppraisalVehicleCard.class)
    @PostMapping("/getAppraisalsCards")
    public ResponseEntity<Object []> getAppraisalsCards(@RequestHeader("userId") Long userId,@RequestParam @Min(1) Integer pageNo,@RequestParam @Min(1) Integer pageSize) {


        try {
            if(userId>0 && pageSize>0) {
                Object[] apv = service.findAllCards(userId, pageNo, pageSize);

                return new ResponseEntity<Object[]>(apv, HttpStatus.OK);
            }else throw new IllegalArgumentException("Invalid userId OR Invalid page size");
        }
        catch (IllegalArgumentException ex){
            ErrorResponse errorResponse = new ErrorResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), ex.getMessage());
            Object[] array=new Object[]{errorResponse};
            return new ResponseEntity<>(array, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        catch (RuntimeException ex){

            ErrorResponse errorResponse = new ErrorResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), ex.getMessage());
            Object[] array=new Object[]{errorResponse};
            return new ResponseEntity<>(array, HttpStatus.INTERNAL_SERVER_ERROR);
        }


    }


//   @ApiIgnore
//    @GetMapping("/getpic1")
//    public ResponseEntity<?> downloadImageFromFileSystem(@RequestParam String pic1) throws IOException {
//        Object[] bytes = service.downloadImageFromFileSystem(pic1);
//        return ResponseEntity.status(HttpStatus.OK)
//                .contentType(MediaType.valueOf("image/jpeg"))
//                .body(bytes);
//
//    }
 /*   @ApiIgnore
    @ApiOperation(value = "Upload Image and Returns image name", response = ApiResponseHandler.class)
    @PostMapping("/uploadImage")
    public ResponseEntity<?> uploadImage(@RequestParam("image1") MultipartFile file1, @RequestParam("image2")
    MultipartFile file2,@RequestParam("image3") MultipartFile file3,@RequestParam("image4") MultipartFile file4) throws IOException {
        Map<Integer,String> map=service.imageUpload(file1,file2,file3,file4);
        return new ResponseEntity<>(map,HttpStatus.OK);
    }*/

}
