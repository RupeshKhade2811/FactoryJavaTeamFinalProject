package com.factory.appraisal.vehiclesearchapp.persistence.model;
// authorName : YogeshKumarV,Rupesh Khade

import com.factory.appraisal.vehiclesearchapp.constants.AppraisalConstants;
import lombok.*;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.envers.AuditTable;
import org.hibernate.envers.Audited;


import javax.persistence.*;

@Audited
@AuditTable(value = "CONFIG_CODES_AUD",schema = "FACTORY_AUD")
//@AuditTable(value = "CONFIG_CODES_AUD",schema = "${audit.schema.name}")                        //#{@environment.getProperty('mySchema')}
@Entity
@Table(name = "CONFIG_CODES",schema = "FACTORY_DB")
//@Table(name = "CONFIG_CODES",schema = "${main.schema.name}")
//@Table(name = "CONFIG_CODES", indexes = {
//        @Index(name = "CONFIG_CODES_CODE_TYPE_IDX", columnList = "CODE_TYPE, SHORT_CODE",unique = true,options = @IndexOptions(name = "CONFIG_CODES_CODE_TYPE_IDX", value = " TS_FACTORY_DB_IDX")),
//        @Index(name = "CONFIG_CODES_IS_ACTIVE_IDX", columnList = "IS_ACTIVE")
//},schema = "FACTORY_DB")
@DynamicUpdate
@DynamicInsert
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

@GenericGenerator(name = AppraisalConstants.SEQUENCE_NAME,
        strategy = AppraisalConstants.CUSTOM_SEQUENCE_GENERATOR,
        parameters = {@Parameter(name = "sequence", value = "config_codes_seq")})
public class EConfigurationCodes extends TransactionEntity {

    private String codeType;
    private String shortCode;
    private String longCode;
    private String shortDescription;



}