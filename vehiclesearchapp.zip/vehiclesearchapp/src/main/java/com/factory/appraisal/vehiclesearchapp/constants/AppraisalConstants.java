package com.factory.appraisal.vehiclesearchapp.constants;

public class AppraisalConstants {
    public static final String FOLDER_PATH="C://myfile/";
    public static final String SEQUENCE_NAME = "mygen";
    public static final String CUSTOM_SEQUENCE_GENERATOR = "com.factory.commons.persistence.generator.CustomIDGenerator";

}
