package com.factory.appraisal.vehiclesearchapp.services;

import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.Map;

public interface AppraiseVehicleService {


    Object[] findAllCards(Long userId, Integer pageNumber, Integer pageSize);
     Object[] downloadImageFromFileSystem(Long appraisalReferenceId);
    Map<Integer,String> imageUpload(MultipartFile file1, MultipartFile file2, MultipartFile file3, MultipartFile file4);




}
