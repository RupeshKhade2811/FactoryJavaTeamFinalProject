package com.factory.appraisal.vehiclesearchapp.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@NoArgsConstructor
public class AppraisalTestDRStsImages {
    private String rearRightImage;
    public String getRearRightImage() {
        return rearRightImage;
    }

    public void setRearRightImage(String rearRightImage) {
        this.rearRightImage = rearRightImage;
    }

//    private String vehiclePicture1;
//
//    public String getVehiclePicture1() {
//        return vehiclePicture1;
//    }
//
//    public void setVehiclePicture1(String vehiclePicture1) {
//        this.vehiclePicture1 = vehiclePicture1;
//    }
}
