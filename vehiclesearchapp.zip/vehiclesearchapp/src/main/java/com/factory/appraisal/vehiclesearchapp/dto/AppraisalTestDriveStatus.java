package com.factory.appraisal.vehiclesearchapp.dto;
//@author:Kalyan


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


import javax.validation.Valid;
import javax.validation.constraints.*;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AppraisalTestDriveStatus {

    private Long vehicleDivingStatusId;

    @Valid
    private AppraisalVehicleAcCondition appraisalVehicleAcCondition;
    @Valid
    private AppraisalVehicleInteriorCondition appraisalVehicleInteriorCondition;
    @Valid
    private AppraisalVehicleOilCondition appraisalVehicleOilCondition;
    @Valid
    private AppraisalVehicleStereoStatus appraisalVehicleStereoStatus;
    @Valid
    private AppraisalVehicleTireCondition appraisalVehicleTireCondition;
    @Valid
    private VehicleDrivingWarnLightStatus vehicleDrivingWarnLightStatus;
    @Size(max = 50)
    private String optionalEquipment;
    @Size(max = 4)
    @NotNull
    private String  engineType;
    @Size(max = 10)
    @NotNull
    private String transmissionType;
    @Size(max = 5)
    @NotNull
    private String steering;
    @Size(max = 30)
    private String doorLocks;
    @Size(max = 17)
    private String  frontLeftSideImage;
    @Size(max = 15)
    @NotNull
    private String leftFrontWindowStatus;
    @Size(max = 15)
    @NotNull
    private String   frontRightWindowStatus;
    @Size(max = 15)
    @NotNull
    private String  rearLeftWindowStatus;
    @Size(max = 15)
    @NotNull
    private String  rearRightWindowStatus;
    @Size(max = 17)
    @NotNull
    private String frontRightImage;
    @Size(max = 17)
    @NotNull
    private String  rearLeftImage;
    @Size(max = 17)
    @NotNull
    private String rearRightImage;
    @Size(max = 30)
    @NotNull
    private String interiorType;
    @Size(max = 30)
    private String lightCondition;
    @Size(max = 50)
    private String roofType;
    @Size(max = 10)
    private String appraisalFollowUp;
    @Size(max = 10)
    private String appraisalInventoryStatus;
    @Size(max = 10)
    private String vehicleExteriorColor;
    @Size(max = 50)
    private String exteriorDamageStatus;
    @Size(max = 50)
    private String frontDriversideDamageTextBox;
    @Size(max = 50)
    private String frontDriversideDamage;
    @Size(max = 50)
    private String frontPassengerSideDamageTextBox;
    @Size(max = 50)
    private String frontPassengerSideDamage;

    // private String optionalEquipment;
    @Size(max = 50)
    private String frontDriversidePaintwork;
    @Size(max = 50)
    private String frontDriversidePaintworkTextBox;
    @Size(max = 50)
    private String paintWorkFrontPassengerSideStatus;
    @Size(max = 50)
    private String frontPassengerSidePaintworkTextBox;
    @Size(max = 50)
    private String rearDriversidePaintwork;
    @Size(max = 50)
    private String rearDriversidePaintworkTextBox;
    @Size(max = 50)
    private String rearPassengerSidePaintwork;
    @Size(max = 50)
    private String rearPassengerSidePaintworkTextBox;
    @Size(max = 50)
    private String paintWork;
    @Size(max = 50)
    private String rearDriversideDamageTextBox;
    @Size(max = 50)
    private String rearDriversideDamage;
    @Size(max = 50)
    private String rearPassengerSideDamageDescription;
    @Size(max = 50)
    private String frontPassengerSidePaintwork;
    @Size(max = 50)
    private String wholesaleBuyFiguresStatus;
    @Size(max = 50)
    private String windshieldDamage;


    private String quickAppraisal;

    private String vehicleMileage;

    private String vehicleInterior;


    private String keyAssureYes;
    private String subscribToKeyAssure;
    private String keyAssureFiles;
    private String brakingSystemStatus;

    private String booksAndKeys;
    private String titleStatus;

    private String adjustedWholsalePoor;
    private String adjustedWholesaleFair;
    private String adjustedWholesaleGood;
    private String adjustedWholesaleVeryGood;
    private String adjustedWholesaleExcellent;
    private String adjustedFinancePoor;
    private String adjustedFinanceFair;
    private  String adjustedFinanceGood;
    private String adjustedFinanceVeryGood;
    private String adjustedFinanceExcellent;
    private String adjustedRetailPoor;
    private  String adjustedRetailFair;
    private String adjustedRetailGood;
    private String adjustedRetailVeryGood;
    private String adjustedRetailExcellent;

    private String pushforBuyfigure;

    private String dealerReserve;
    private String comsumerAskingPrice;
    private String dealerRetailAskingPric;

    private String professionalOpinion;

    private String frontDriversideDamagePicture;

    private String rearDriversideDamagePicture;

    private String rearPassengerSideDamagePicture;

    private String frontPassengerSideDamagePicture;

    private String frontDriversidePaintworkPicture;

    private String rearDriversidePaintworkPicture;
    private String frontPassengerSidePaintworkPicture;

    private String frontWindshieldDamage;
    private String  rearGlassDamage;
}
