package com.factory.appraisal.vehiclesearchapp.persistence.model;
//@author:Rupesh Khade

import com.factory.appraisal.vehiclesearchapp.constants.AppraisalConstants;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

import org.hibernate.envers.AuditTable;
import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import javax.persistence.*;
import java.util.List;

@Audited
@Entity
@Table(name = "APR_TEST_DR_STATUS")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@DynamicUpdate
@DynamicInsert
@AttributeOverride(name = "id", column = @Column(name = "VEH_STATUS_ID"))
@AttributeOverride(name = "valid",column= @Column(name = "IS_ACTIVE"))
@AttributeOverride(name="createdBy",column =@Column(name = "CREATED_BY"))
@AttributeOverride(name="createdOn",column =@Column(name = "CREATED_ON"))
@AttributeOverride(name=" modifiedBy",column =@Column(name = "MODIFIED_BY"))
@AttributeOverride(name="modifiedOn",column =@Column(name = "MODIFIED_ON"))

@GenericGenerator(name = AppraisalConstants.SEQUENCE_NAME,
        strategy = AppraisalConstants.CUSTOM_SEQUENCE_GENERATOR,
        parameters = {@Parameter(name = "sequence", value = "APR_TEST_DR_STATUS_SEQ")})

public class EAppraisalTestDriveStatus extends TransactionEntity {

//    @Column(name = "VEH_STATUS_ID")
//    private Long vehicleDivingStatusId;
    @Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
    @OneToOne(targetEntity = EAppraiseVehicle.class, fetch = FetchType.LAZY)
    @JoinColumn(name = "APPRAISAL_REF ", referencedColumnName = "APPR_REF_ID", nullable = false)
    private EAppraiseVehicle appraisalRef;

    @Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
    @OneToOne(mappedBy = "vehicleStatus", cascade = CascadeType.ALL)
    private EAppraisalVehicleAcCondition appraisalVehicleAcCondition;

    @Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
    @OneToOne(mappedBy = "vehicleStatus", cascade = CascadeType.ALL)
    private EAppraisalVehicleInteriorCondition appraisalVehicleInteriorCondition;
    @Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
    @OneToOne(mappedBy = "vehicleStatus", cascade = CascadeType.ALL)
    private EAppraisalVehicleOilCondition appraisalVehicleOilCondition;

    @Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
    @OneToOne(mappedBy = "vehicleStatus", cascade = CascadeType.ALL)
    private EAppraisalVehicleStereoStatus appraisalVehicleStereoStatus;

    @Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
    @OneToOne(mappedBy = "vehicleStatus", cascade = CascadeType.ALL)
    private EAppraisalVehicleTireCondition appraisalVehicleTireCondition;

    @Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
    @OneToOne(mappedBy = "vehicleStatus", cascade = CascadeType.ALL)
    private EVehicleDrivingWarnLightStatus vehicleDrivingWarnLightStatus;


    @Column(name = "OPT_EQUIPMENT")
    private String optionalEquipment;   //this maybe a table
    @Column(name = "ENGINE_TYPE")
    private String engineType;
    @Column(name = "TRANSMISSION_TYPE ")
    private String transmissionType;
    @Column(name = " STEERING")
    private String steering;
    @Column(name = "DR_LOCK_TYPE")
    private String doorLocks;
    @Column(name = "F_L_IMAGE")
    private String frontLeftSideImage;
    @Column(name = "F_L_WIN_STATUS ")
    private String leftFrontWindowStatus;
    @Column(name = "F_R_WIN_STATUS")
    private String frontRightWindowStatus;
    @Column(name = "R_L_WIN_STATUS ")
    private String rearLeftWindowStatus;
    @Column(name = "R_R_WIN_STATUS")
    private String rearRightWindowStatus;
    @Column(name = "F_R_IMAGE")
    private String frontRightImage;
    @Column(name = "R_L_IMAGE")
    private String rearLeftImage;
    @Column(name = "R_R_IMAGE", nullable = false)
    private String rearRightImage;
    @Column(name = "INTR_TYPE")
    private String interiorType;
    @Column(name = "LIGHT_CONDN ")
    private String lightCondition;
    @Column(name = "ROOF_TYPE")
    private String roofType;
    @Column(name = "APR_FOLLOW_UP ")
    private String appraisalFollowUp;
    @Column(name = "APR_INV_STATUS ")
    private String appraisalInventoryStatus;
    @Column(name = "EXTR_COLOR")
    private String exteriorColor;
    @Column(name = "EXTR_DMG_STATUS ")
    private String exteriorDamageStatus;
    @Column(name = "F_DR_SIDE_DMG_DESC")
    private String frontDriversideDamageTextBox;
    @Column(name = "F_DR_SIDE_DMG_STS")
    private String frontDriversideDamage;
    @Column(name = "F_P_SIDE_DMG_DESC")
    private String frontPassengerSideDamageTextBox;
    @Column(name = "F_P_SIDE_DMG_STS ")
    private String frontPassengerSidePaintwork;


    @Column(name = "PNTWRK_FD_SIDE_STS ")
    private String frontDriversidePaintwork;
    @Column(name = "PNTWRK_FD_SIDE_STS_DESC")
    private String frontDriversidePaintworkTextBox;
    @Column(name = "PNTWRK_FP_SIDE_STS")
    private String paintWorkFrontPassengerSideStatus;
    @Column(name = "PNTWRK_FP_SIDE_STS_DESC")
    private String frontPassengerSidePaintworkTextBox;
    @Column(name = "PNTWRK_RD_SIDE_STS")
    private String rearDriversidePaintwork;
    @Column(name = "PNTWRK_RD_SIDE_STS_DESC")
    private String rearDriversidePaintworkTextBox;
    @Column(name = "PNTWRK_RP_SIDE_STS")
    private String rearPassengerSidePaintwork;
    @Column(name = "PNTWRK_RP_SIDE_STS_DESC")
    private String rearPassengerSidePaintworkTextBox;
    @Column(name = "PNTWRK_STATUS")
    private String paintWork;
    @Column(name = "R_DR_SIDE_DMG_DESC")
    private String rearPassengerSideDamageTextBox;
    @Column(name = "R_DR_SIDE_DMG_STS ")
    private String rearDriversideDamage;
    @Column(name = "R_PASS_SIDE_DMG_DESC")
    private String rearPassengerSideDamageDescription;
    @Column(name = "R_PASS_SIDE_DMG_STS ")
    private String rearPassengerSideDamage;
    @Column(name = "WS_BUY_FIG_STS ")
    private String wholesaleBuyFiguresStatus;
    @Column(name = "WIND_SHIELD_DMG")
    private String windshieldDamage;


    @Column(name = "QUIK_APPRAISAL")
    String quickAppraisal;
    @Column(name = "VECLE_MILEAGE")
    private String vehicleMileage;

    @Column(name = "KEY_ASSUR_YES")
    private String keyAssureYes;

    @Column(name = "SUBSCB_TO_KEY_ASSURE")
    private String subscribToKeyAssure;

    @Column(name = "KEY_ASSUR_FILE")
    private String keyAssureFiles;
    @Column(name = "BRAKE_SYS_STATS")
    private String brakingSystemStatus;
    @Column(name = "BOOKS_AND_KEYS")
    private String booksAndKeys;
    @Column(name = "TITL_STATS")
    private  String titleStatus;

    @Column(name = "ADJS_WHOLE_POOR")
    private  String adjustedWholsalePoor;
    @Column(name = "ADJS_WHOLE_SALE_FAIR")
    private  String adjustedWholesaleFair;
    @Column(name = "ADJS_WHOLE_SALE_GOOD")
    private String adjustedWholesaleGood;
    @Column(name = "ADJS_WHOLE_SALE_VERY_GOOD")
    private  String adjustedWholesaleVeryGood;
    @Column(name = "ADJS_WHOLE_SALE_EXCELNT")
    private  String adjustedWholesaleExcellent;
    @Column(name = "ADJS_FINAN_POOR")
    private  String adjustedFinancePoor;
    @Column(name = "ADJS_FINAN_FAIR")
    private  String adjustedFinanceFair;
    @Column(name = "ADJS_FINAN_GOOD")
    private  String adjustedFinanceGood;
    @Column(name = "ADJS_FINAN_VERY_GOOD")
    private  String adjustedFinanceVeryGood;
    @Column(name = "ADJS_FINAN_EXCLNT")
    private  String adjustedFinanceExcellent;
    @Column(name = "ADJS_RETL_POOR")
    private String adjustedRetailPoor;
    @Column(name = "ADJS_RETL_FAIR")
    private String adjustedRetailFair;
    @Column(name = "ADJS_RETL_GOOD")
    private String adjustedRetailGood;
    @Column(name = "ADJS_RETL_VRY_GOOD")
    private  String adjustedRetailVeryGood;

    @Column(name = "ADJS_RETL_EXCLNT")
    private  String adjustedRetailExcellent;
    @Column(name = "PUSH_FOR_BUY_FIG")
    private String pushforBuyfigure;
    @Column(name = "DEALR_RESRV")
    private String dealerReserve;
    @Column(name = "CONSMR_ASK_PRIC")
    private String comsumerAskingPrice;
    @Column(name = "DELR_RETL_ASK_PRIC")
    private String dealerRetailAskingPrice;

    //picture

    private String vehiclePicture1;
    private String vehiclePicture2;
    private String vehiclePicture3;
    private String vehiclePicture4;
    private String vehiclePicture5;
    private String vehiclePicture6;
    private String vehiclePicture7;
    private String vehiclePicture8;
    private String vehiclePicture9;
    private String vehicleVideo1;


    private String frontDriversideDamagePicture;

    private String rearDriversideDamagePicture;
    private String rearPassengerSideDamagePicture;

    private String frontPassengerSideDamagePicture;

    private String frontDriversidePaintworkPicture;

    private String rearDriversidePaintworkPicture;

    private String rearPassengerSidePaintworkPicture;

    private String frontPassengerSidePaintworkPicture;

    private String frontWindshieldDamage;
    private String  rearGlassDamage;

}