package com.factory.appraisal.vehiclesearchapp.services;
//Author:Rupesh khade

import com.factory.appraisal.vehiclesearchapp.ExceptionHandle.ApplicationExceptionHandler;
import com.factory.appraisal.vehiclesearchapp.constants.AppraisalConstants;
import com.factory.appraisal.vehiclesearchapp.dto.AppraisalVehicleCard;

import com.factory.appraisal.vehiclesearchapp.dto.PageInfo;
import com.factory.appraisal.vehiclesearchapp.persistence.mapper.*;
import com.factory.appraisal.vehiclesearchapp.persistence.model.EAppraiseVehicle;
import com.factory.appraisal.vehiclesearchapp.repository.*;

import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

@Service
public class AppraiseVehicleServiceImpl implements AppraiseVehicleService {
    @Autowired
    private AppraiseVehicleRepo eAppraiseVehicleRepo;
    @Autowired

    private UserRegistrationRepo userRegistrationRepo;

    @Autowired
    AppraisalTestDriveStatusRepo eAppraisalTestDriveStatusRepo;
    @Autowired
    private AppraisalVehicleMapper appraisalVehicleMapper;
    @Autowired
    private ApplicationExceptionHandler exceptionHandler;

    @Override
    public Object[] findAllCards(Long userId, Integer pageNumber, Integer pageSize)  {

        Pageable pageable = PageRequest.of(pageNumber, pageSize, Sort.by("createdOn").descending());

        Page<EAppraiseVehicle> pageResult = eAppraiseVehicleRepo.findAllByValidIsTrueAndUserIdOrderByCreatedOnDesc(userId, pageable);

        if(pageResult.getTotalElements()!=0) {

            PageInfo pageInfo = new PageInfo();
            pageInfo.setTotalRecords(pageResult.getTotalElements());
            pageInfo.setTotalPages(pageResult.getTotalPages());

            List<EAppraiseVehicle> apv = pageResult.toList();

            List<AppraisalVehicleCard> appraiseVehicleDtos = appraisalVehicleMapper.lEApprVehiToLApprVehiCard(apv);
            ArrayList<EAppraiseVehicle> al1 = new ArrayList<>(apv);

            ArrayList<AppraisalVehicleCard> al2 = new ArrayList<>(appraiseVehicleDtos);

            for (int i = 0; i < al1.size(); i++) {
                al2.get(i).setImage(al1.get(i).getAppraisalTestDriveStatus().getVehiclePicture1());
            }

            Object[] array = new Object[]{appraiseVehicleDtos,pageInfo};

            return array;
        }
        else throw new RuntimeException("AppraisalCards not available");

    }

/*
    public Object[] downloadImageFromFileSystem(Long appraisalReferenceId)  {

         EAppraiseVehicle vehicle = eAppraiseVehicleRepo.findById(appraisalReferenceId).orElse(null);
         if (vehicle != null) {


             String filePath = AppraisalConstants.FOLDER_PATH + vehicle.getAppraisalTestDriveStatus().getRearRightImage();
           try {
               byte[] images = Files.readAllBytes(new File(filePath).toPath());//Reading from folder
               Object[] obj=new Object[]{images};
               return obj;
           }catch (IOException e){
               System.out.println(e.getMessage());
           }
         } else throw new RuntimeException("ImageNot found for given Id");

     return null;
    }

    */

  /*  @Override
    public Map<Integer,String> imageUpload(MultipartFile file1,MultipartFile file2,MultipartFile file3,MultipartFile file4) {

        Map<Integer, String> map = new TreeMap<>();

        for (int i = 1; i <= 4; i++) {
            MultipartFile file = null;
            switch (i) {
                case 1:
                    file = file1;
                    break;
                case 2:
                    file = file2;
                    break;
                case 3:
                    file = file3;
                    break;
                case 4:
                    file = file4;
                    break;
            }
            if (file != null) {
                String extension = FilenameUtils.getExtension(file.getOriginalFilename());
                String filename = UUID.randomUUID().toString() + "." + extension;
                Path filePath = Paths.get(AppraisalConstants.FOLDER_PATH + filename);
                try{ Files.write(filePath, file.getBytes());

                }
                catch (IOException exception){

                }

                map.put(i, filename);
            }
        }


        return map;
    }*/
}
